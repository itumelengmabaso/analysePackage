# analysePackage
This is a Analyse Package with 7 Python Functions for Data Analysis

## Building this package locally
`python setup.py sdist`

## Installing the package from github
`pip install git+https://github.com/itumelengmabaso/analysePackage.git`

## Upgrading the package from github
`pip install --upgrade git+https://github.com/itumelengmabaso/analysePackage.git`
